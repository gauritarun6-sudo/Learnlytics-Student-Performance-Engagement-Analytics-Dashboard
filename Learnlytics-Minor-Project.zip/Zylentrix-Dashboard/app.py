import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from pathlib import Path

st.set_page_config(page_title='Learnlytics | Student Analytics', page_icon='📊', layout='wide', initial_sidebar_state='expanded')
ROOT = Path(__file__).parent

@st.cache_data
def load_data():
    students = pd.read_csv(ROOT / 'students.csv')
    activity = pd.read_csv(ROOT / 'course_activity.csv')
    feedback = pd.read_csv(ROOT / 'feedback.csv')
    students['Enrolment_Date'] = pd.to_datetime(students['Enrolment_Date'], dayfirst=True, errors='coerce')
    activity['Date'] = pd.to_datetime(activity['Date'], dayfirst=True, errors='coerce')
    for c in ['Age']:
        students[c] = pd.to_numeric(students[c], errors='coerce')
    for c in ['Time_Spent_Minutes', 'Completion_Percentage']:
        activity[c] = pd.to_numeric(activity[c], errors='coerce')
    feedback['Rating'] = pd.to_numeric(feedback['Rating'], errors='coerce')
    return students, activity, feedback

students, activity, feedback = load_data()

st.markdown('''<style>
.block-container{padding-top:1.6rem;padding-bottom:2rem;max-width:1500px}
[data-testid="stMetric"]{background:linear-gradient(135deg,#172554,#1e3a8a);padding:16px 18px;border-radius:14px;border:1px solid #334b86}
[data-testid="stMetricLabel"]{color:#cbd5e1!important}
[data-testid="stMetricValue"]{color:#fff!important}
section[data-testid="stSidebar"]{background:#0b1220}
.small-muted{color:#94a3b8;font-size:0.9rem}
</style>''', unsafe_allow_html=True)

st.title('📊 Learnlytics')
st.markdown('### Student Performance & Engagement Analytics')
st.markdown('<p class="small-muted">Explore learner activity, course completion, satisfaction and student demographics.</p>', unsafe_allow_html=True)

# Sidebar filters
st.sidebar.title('🎛️ Dashboard Filters')
st.sidebar.caption('Filters update every chart and KPI.')
locations = sorted(students['Location'].dropna().unique().tolist())
genders = sorted(students['Gender'].dropna().unique().tolist())
courses = sorted(activity['Course_ID'].dropna().unique().tolist())
sel_locations = st.sidebar.multiselect('Location', locations, default=locations)
sel_genders = st.sidebar.multiselect('Gender', genders, default=genders)
sel_courses = st.sidebar.multiselect('Course', courses, default=courses)
min_date = activity['Date'].min().date() if activity['Date'].notna().any() else None
max_date = activity['Date'].max().date() if activity['Date'].notna().any() else None
if min_date and max_date:
    date_range = st.sidebar.date_input('Activity date range', value=(min_date, max_date), min_value=min_date, max_value=max_date)
else:
    date_range = None

s = students[students['Location'].isin(sel_locations) & students['Gender'].isin(sel_genders)].copy()
a = activity[activity['Course_ID'].isin(sel_courses)].copy()
if date_range and isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    a = a[a['Date'].dt.date.between(date_range[0], date_range[1])]
valid_ids = set(s['Student_ID'])
a = a[a['Student_ID'].isin(valid_ids)]
f = feedback[feedback['Course_ID'].isin(sel_courses) & feedback['Student_ID'].isin(valid_ids)].copy()

# KPIs
active_students = a['Student_ID'].nunique()
avg_completion = a['Completion_Percentage'].mean() if not a.empty else 0
avg_rating = f['Rating'].mean() if not f.empty else 0
total_hours = a['Time_Spent_Minutes'].sum()/60 if not a.empty else 0
k1,k2,k3,k4 = st.columns(4)
k1.metric('Students in view', f'{len(s):,}')
k2.metric('Active learners', f'{active_students:,}')
k3.metric('Avg. course completion', f'{avg_completion:.1f}%')
k4.metric('Avg. feedback rating', f'{avg_rating:.2f}/5' if not f.empty else 'N/A')
st.caption(f"Activity records: {len(a):,}  •  Learning time: {total_hours:,.1f} hours  •  Feedback responses: {len(f):,}")

if s.empty or a.empty:
    st.warning('No records match the selected filters. Please widen or clear the sidebar filters.')
    st.stop()

# Tabs
t1,t2,t3,t4,t5 = st.tabs(['🏠 Overview','📚 Course Analysis','👩‍🎓 Students','⭐ Feedback','💡 Insights & Data'])
with t1:
    left,right = st.columns(2)
    with left:
        monthly = a.dropna(subset=['Date']).assign(Month=lambda d:d['Date'].dt.to_period('M').astype(str)).groupby('Month',as_index=False).agg(Study_Minutes=('Time_Spent_Minutes','sum'),Activity_Records=('Student_ID','count'))
        fig=px.line(monthly,x='Month',y='Study_Minutes',markers=True,title='Learning activity over time',template='plotly_dark')
        fig.update_layout(xaxis_title='',yaxis_title='Minutes studied')
        st.plotly_chart(fig,use_container_width=True)
    with right:
        loc=s.groupby('Location',as_index=False).size().sort_values('size',ascending=False)
        fig=px.bar(loc,x='Location',y='size',color='size',title='Students by location',template='plotly_dark',labels={'size':'Students'})
        fig.update_layout(showlegend=False,xaxis_title='',yaxis_title='Students')
        st.plotly_chart(fig,use_container_width=True)
    c1,c2=st.columns(2)
    with c1:
        fig=px.histogram(a,x='Completion_Percentage',nbins=18,title='Distribution of course completion',template='plotly_dark',color_discrete_sequence=['#38bdf8'])
        fig.update_layout(xaxis_title='Completion (%)',yaxis_title='Activity records')
        st.plotly_chart(fig,use_container_width=True)
    with c2:
        g=s.groupby('Gender',as_index=False).size()
        fig=px.pie(g,names='Gender',values='size',hole=.55,title='Student gender mix',template='plotly_dark')
        st.plotly_chart(fig,use_container_width=True)

with t2:
    course = a.groupby('Course_ID',as_index=False).agg(Activities=('Student_ID','count'),Learners=('Student_ID','nunique'),Avg_Completion=('Completion_Percentage','mean'),Study_Minutes=('Time_Spent_Minutes','sum'))
    if not f.empty:
        fr=f.groupby('Course_ID',as_index=False).agg(Avg_Rating=('Rating','mean'),Responses=('Rating','count'))
        course=course.merge(fr,on='Course_ID',how='left')
    l,r=st.columns(2)
    with l:
        fig=px.bar(course.sort_values('Avg_Completion',ascending=False),x='Course_ID',y='Avg_Completion',color='Avg_Completion',title='Average completion by course',template='plotly_dark',labels={'Avg_Completion':'Completion (%)'})
        st.plotly_chart(fig,use_container_width=True)
    with r:
        fig=px.bar(course.sort_values('Study_Minutes',ascending=False),x='Course_ID',y='Study_Minutes',color='Study_Minutes',title='Total learning time by course',template='plotly_dark')
        st.plotly_chart(fig,use_container_width=True)
    st.subheader('Course performance summary')
    st.dataframe(course.round(2),use_container_width=True,hide_index=True)

with t3:
    l,r=st.columns(2)
    with l:
        age=s.dropna(subset=['Age'])
        fig=px.histogram(age,x='Age',nbins=15,color='Gender',title='Student age distribution',template='plotly_dark')
        st.plotly_chart(fig,use_container_width=True)
    with r:
        per_student=a.groupby('Student_ID',as_index=False).agg(Activities=('Course_ID','count'),Avg_Completion=('Completion_Percentage','mean'),Study_Minutes=('Time_Spent_Minutes','sum'))
        fig=px.scatter(per_student,x='Study_Minutes',y='Avg_Completion',size='Activities',hover_name='Student_ID',title='Study time vs. average completion',template='plotly_dark',labels={'Study_Minutes':'Study time (minutes)','Avg_Completion':'Avg. completion (%)'})
        st.plotly_chart(fig,use_container_width=True)
    st.subheader('Learner activity table')
    st.dataframe(per_student.sort_values('Avg_Completion',ascending=False).round(2),use_container_width=True,hide_index=True)

with t4:
    if f.empty:
        st.info('No feedback records match the current filters.')
    else:
        l,r=st.columns(2)
        with l:
            rating=f.groupby('Rating',as_index=False).size()
            fig=px.bar(rating,x='Rating',y='size',title='Feedback rating distribution',template='plotly_dark',color='Rating',labels={'size':'Responses'})
            st.plotly_chart(fig,use_container_width=True)
        with r:
            by_course=f.groupby('Course_ID',as_index=False).agg(Avg_Rating=('Rating','mean'),Responses=('Rating','count'))
            fig=px.bar(by_course,x='Course_ID',y='Avg_Rating',color='Avg_Rating',title='Average satisfaction by course',template='plotly_dark',labels={'Avg_Rating':'Average rating'})
            st.plotly_chart(fig,use_container_width=True)
        st.subheader('Student comments')
        st.dataframe(f[['Student_ID','Course_ID','Rating','Feedback_Text']],use_container_width=True,hide_index=True)

with t5:
    st.subheader('Key observations')
    best = a.groupby('Course_ID')['Completion_Percentage'].mean().idxmax() if not a.empty else 'N/A'
    low = a.groupby('Course_ID')['Completion_Percentage'].mean().idxmin() if not a.empty else 'N/A'
    st.markdown(f'- **Highest average completion:** {best}.')
    st.markdown(f'- **Lowest average completion:** {low}.')
    st.markdown(f'- **Average completion across filtered activity:** {avg_completion:.1f}%.')
    st.markdown(f'- **Average learner satisfaction:** {avg_rating:.2f}/5.' if not f.empty else '- **Learner satisfaction:** No feedback in current selection.')
    st.info('Interpretation: Course teams can use completion and feedback together to identify courses that may need clearer content, pacing changes or additional learner support. These are descriptive insights, not proof of cause and effect.')
    st.subheader('Filtered source data')
    st.download_button('⬇️ Download activity data (CSV)',a.to_csv(index=False).encode('utf-8'),file_name='filtered_course_activity.csv',mime='text/csv')
    st.download_button('⬇️ Download student data (CSV)',s.to_csv(index=False).encode('utf-8'),file_name='filtered_students.csv',mime='text/csv')
    st.download_button('⬇️ Download feedback data (CSV)',f.to_csv(index=False).encode('utf-8'),file_name='filtered_feedback.csv',mime='text/csv')

st.divider()
st.markdown('<p class="small-muted">Learnlytics • MCA Minor Project • Built with Python, Streamlit, Pandas and Plotly</p>',unsafe_allow_html=True)
