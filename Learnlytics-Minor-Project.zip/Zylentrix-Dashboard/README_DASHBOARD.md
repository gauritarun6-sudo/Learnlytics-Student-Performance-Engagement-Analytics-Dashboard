# Learnlytics — Student Performance & Engagement Analytics Dashboard

## Run locally (Windows / VS Code)

1. Open this folder in VS Code.
2. Open Terminal (`Ctrl + ``).
3. Create and activate an environment (optional if your existing `.venv` works):

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

4. Install dependencies:

```powershell
python -m pip install -r requirements.txt
```

5. Start the dashboard:

```powershell
python -m streamlit run app.py
```

6. Open the local URL printed in the terminal (normally http://localhost:8501).

Keep `students.csv`, `course_activity.csv`, and `feedback.csv` in the same folder as `app.py`.

## Features
- KPI cards for student count, active learners, average completion and feedback rating
- Sidebar filters for location, gender, course and date range
- Overview, course analysis, learner analysis, feedback and insights pages
- Interactive Plotly charts and CSV downloads

## Project note
This is a descriptive analytics dashboard based on the supplied sample datasets. It does not claim to predict student outcomes or establish causal relationships.
